import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class NotepadApp extends JFrame implements ActionListener {

    JTextArea textArea;
    JMenuBar menuBar;
    JMenu editMenu, helpMenu;
    JMenuItem cutItem, copyItem, pasteItem;
    JMenuItem aboutItem;
    JMenuItem fontItem, colorItem;

    public NotepadApp() {
        setTitle("Notepad Application");
        setSize(600, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        textArea = new JTextArea();
        add(new JScrollPane(textArea), BorderLayout.CENTER);

        menuBar = new JMenuBar();

        editMenu = new JMenu("Edit");
        cutItem = new JMenuItem("Cut");
        copyItem = new JMenuItem("Copy");
        pasteItem = new JMenuItem("Paste");

        cutItem.addActionListener(this);
        copyItem.addActionListener(this);
        pasteItem.addActionListener(this);

        editMenu.add(cutItem);
        editMenu.add(copyItem);
        editMenu.add(pasteItem);

        fontItem = new JMenuItem("Font");
        colorItem = new JMenuItem("Color");
        fontItem.addActionListener(this);
        colorItem.addActionListener(this);
        editMenu.addSeparator();
        editMenu.add(fontItem);
        editMenu.add(colorItem);

        helpMenu = new JMenu("Help");
        aboutItem = new JMenuItem("About");
        aboutItem.addActionListener(this);
        helpMenu.add(aboutItem);

        menuBar.add(editMenu);
        menuBar.add(helpMenu);
        setJMenuBar(menuBar);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == cutItem) {
            textArea.cut();
        } else if (e.getSource() == copyItem) {
            textArea.copy();
        } else if (e.getSource() == pasteItem) {
            textArea.paste();
        } else if (e.getSource() == aboutItem) {
            JOptionPane.showMessageDialog(this,
                    "Notepad Application\nCreated by: Your Name\nID: YourID",
                    "About", JOptionPane.INFORMATION_MESSAGE);
        } else if (e.getSource() == fontItem) {
            String[] fonts = GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();
            String chosenFont = (String) JOptionPane.showInputDialog(this,
                    "Choose Font", "Font Chooser",
                    JOptionPane.PLAIN_MESSAGE, null, fonts, textArea.getFont().getFamily());
            if (chosenFont != null) {
                textArea.setFont(new Font(chosenFont, Font.PLAIN, 16));
            }
        } else if (e.getSource() == colorItem) {
            Color chosenColor = JColorChooser.showDialog(this, "Choose Text Color", textArea.getForeground());
            if (chosenColor != null) {
                textArea.setForeground(chosenColor);
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new NotepadApp().setVisible(true);
        });
    }
}