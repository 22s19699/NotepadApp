Notepad Application


Description:
This project is a simple Notepad Application built using Java Swing.
It allows users to write and edit text with basic editing features.
Additionally, it provides font and color customization, and an About dialog.

Features:
- Edit Menu
  * Cut
  * Copy
  * Paste
  * Font chooser (optional)
  * Color chooser (optional)

- Help Menu
  * About (shows developer name and ID)

Requirements:
- Java JDK 8 or higher
- Any Java IDE (Eclipse, IntelliJ IDEA, NetBeans) or command line

How to Run:
1. Save the file as NotepadApp.java
2. Open terminal or command prompt
3. Compile the program:
   javac NotepadApp.java
4. Run the program:
   java NotepadApp
5. A window will open with the Notepad application.

Developer:
Name: Your Name
ID: Your ID
